<?php
//x2 - x1 = 82 - 8 = 74
//y2 - y1 = 32 - 32 = 0
$homewidth = "74";
//x2 - x1 = 192 - 82 = 110
//y2 - y1 = 32 - 32 = 0
$categorieswidth = "110";
//x2 - x1 = 324 - 192 = 132
//y2 - y1 = 32 - 32 = 0
$privacypolicywidth = "132";
//x2 - x1 = 430 - 324 = 106
//y2 - y1 = 32 - 32 = 0
$disclaimerwidth = "106";
//x2 - x1 = 528 - 430 = 98
//y2 - y1 = 32 - 32 = 0
$aboutwidth = "98";
//x2 - x1 = 638 - 528 = 110
//y2 - y1 = 32 - 32 = 0
$contactwidth = "110";
//Calculate(calculateDistance(42,32,118,36),110);
if(isset($_GET["x1"]))
{
$x1 = $_GET["x1"];
$y1 = $_GET["y1"];
$x2 = $_GET["x2"];
$y2 = $_GET["y2"];
$width = $_GET["width"];
if(strpos($width,"-")!==false)
{
$m = explode("-",$width);
$n=$m[0]-$m[1];
$width=$n;
echo Calculate(calculateDistance($x1,$x2,$y1,$y2),$width);
}
else
{
echo Calculate(calculateDistance($x1,$x2,$y1,$y2),$width);
}
}
function Calculate($d,$w)
{
return log(2*$d/$w,2);
}
//calculateDistance(10,12,15,20);
function calculateDistance($x1,$x2,$y1,$y2)
{
return hypot($x2-$x1,$y2-$y1);
}
?>