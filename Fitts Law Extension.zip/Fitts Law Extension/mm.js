//onmousemove = function(e){alert(e.client+','+e.clientY);}
//onmousemove = function(e){document.getElementById('xy').value=e.clientX+","+e.clientY;}
// JavaScript Document