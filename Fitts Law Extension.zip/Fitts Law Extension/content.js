 document.addEventListener('DOMContentLoaded', function() {
  document.getElementById("Submit").addEventListener("click", DoSomething);
});
function DoSomething() {
var x1 = document.getElementById("x1").value;
var y1 = document.getElementById("y1").value;
var x2 = document.getElementById("x2").value;
var y2 = document.getElementById("y2").value;
var width = document.getElementById("width").value;
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
	var xin = this.responseText;
     document.getElementById("lb").value = xin.trim();
    }
  };
  xhttp.open("GET", "http://127.0.0.1/D4UOnline/values.php?x1="+x1+"&y1="+y1+"&x2="+x2+"&y2="+y2+"&width="+width, true);
  xhttp.send();
}